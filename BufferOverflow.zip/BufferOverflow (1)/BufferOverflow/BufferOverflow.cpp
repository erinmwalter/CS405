// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_order
  //  varaible, and its position in the declaration. It must always be directly before the variable used for input.

  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  std::string inputtedData;
  std::cout << "Enter a value: ";
  //instead of allowing user to enter data right into user_input, putting it into a string
  //value here so that it can then be transferred into the user input char array manually
  //this will prevent overflow from happening from just the input itself
  std::cin >> inputtedData;

  //checking input data's length before transferring to user_input.
  if (inputtedData.length() >= 20)
  {
	  //if input is too long, truncate it
	  std::cout << "You Entered: " << inputtedData << ". Length >= 20 chars, truncating input" << std::endl;
	  inputtedData = inputtedData.substr(0, 19);
  }

  //now that we have handled the string being too long, we an copy over to user_input char array. 
  strcpy_s(user_input, inputtedData.c_str());
 
  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
