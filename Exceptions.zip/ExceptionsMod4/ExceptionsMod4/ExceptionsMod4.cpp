// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

//custom exception defined here
class CustomException : public std::exception {
public: 
    virtual const char* what() const throw() {
        return "My Custom Exception Thrown!";
    }
};

bool do_even_more_custom_application_logic()
{
        std::cout << "Running Even More Custom Application Logic." << std::endl;
        //throwing standard runtime_error exception here
        throw std::runtime_error("Error: runtime_error thrown in do_even_more_custom_application_logic");

    return true;
}
void do_custom_application_logic()
{
    CustomException ex;
    //wrapped in a try catch block to catch the standard exception thrown in do_even_more_custom_application_logic
    std::cout << "Running Custom Application Logic." << std::endl;
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (std::exception& e) {
        std::cout << "Exception Thrown: " << e.what() << std::endl;
    }

   //custom exception to be thrown here and will be caught in main
    throw ex;
    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    if (den == 0)
    {
        //checks if denominator is 0 before attempting division, if it is, then
        //throws this error and continues.
        throw std::range_error("Divide By Zero Error in do_division, cannot complete division");
        return num;
    }
    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;
    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    //catches the range error thrown by division if cannot divide by zero
    catch (std::range_error& ex) {
        std::cout << "Division Error Thrown: " << ex.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    try {
        //will try these, and once inside these first will throw and catch do_division error
        //next will throw and catch do_even_more_custom_application_logic error
        do_division();
        do_custom_application_logic();
    }
    catch (CustomException& e)
    {
        //then will catch the custom error that is thrown in do_custom_application_logic method
        std::cout << "Custom Error Thrown: " << e.what() << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu